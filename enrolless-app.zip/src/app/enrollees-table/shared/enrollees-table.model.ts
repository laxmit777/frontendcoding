export class EnrolleesTable {
	id: number;
	name: string;
}